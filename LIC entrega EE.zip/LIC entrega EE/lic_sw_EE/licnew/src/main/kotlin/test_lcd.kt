import isel.leic.utils.Time

fun test_lcd(){
    HAL.init()
    LCD.init()
    Time.sleep(1000)

    var cnt = 0
    while(true){
        LCD.write("banana")
        Time.sleep(1000)
        LCD.clear()
    }
}

fun main(){
    test_lcd()
    //App.init()
    //LCD.write("ola")
}