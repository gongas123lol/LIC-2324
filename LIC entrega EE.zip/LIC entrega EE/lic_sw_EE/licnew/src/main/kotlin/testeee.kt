fun main(){
    App.init()
    while(true){
        val read = KBD.waitKey(100)
        if(read != KBD.NONE.toChar()){
            LCD.write(read)
        }

    }
}