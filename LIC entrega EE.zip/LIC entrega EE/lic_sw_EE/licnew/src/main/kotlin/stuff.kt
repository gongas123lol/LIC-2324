fun main(){

    HAL.init()
    SerialEmitter.init()
    LCD.init()
    KBD.init()
    //ScoreDisplay.init()
    //SerialEmitter.send(SerialEmitter.Destination.LCD,0xFF,8)
    LCD.write("olaaaa")


    while(true){
        //println(HAL.readBits(0xFF))
        val a = KBD.waitKey(10)
        if(a != KBD.NONE.toChar()){
            LCD.clear()
            LCD.write(a)
            //ScoreDisplay.setScore(a.code)
        }

        Thread.sleep(100)
    }



}