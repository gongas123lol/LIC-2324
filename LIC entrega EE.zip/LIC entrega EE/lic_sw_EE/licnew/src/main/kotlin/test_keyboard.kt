import isel.leic.UsbPort
import isel.leic.utils.Time

fun test_keyboard(){
    HAL.init()
    KBD.init()

    while(true){
        //println(HAL.readBits(0xFF))
        val read = KBD.waitKey(100)
        if(read != KBD.NONE.toChar()){
            println("read: "+read)

            Time.sleep(200)
        }
        //println(UsbPort.read())


    }
}

fun main(){
    test_keyboard()
}