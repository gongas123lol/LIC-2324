object coinAcceptor {

    const val COIN_MASK =    0b01000000
    const val COINACK_MASK = 0b01000000
    private var avaiable = false

    fun check(){
       avaiable = HAL.isBit(COIN_MASK)
    }
    fun read(): Boolean{
        check()
        return avaiable
    }
    fun accept(){
        while(HAL.isBit(COIN_MASK)){
            //do nothing
        }
        return
    }


}

fun main(){
    HAL.init()
    while(true){
        println(HAL.isBit(TUI.M_MASK))
    }
}